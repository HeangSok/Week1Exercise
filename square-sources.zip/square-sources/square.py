# file: square.py
# Print the square of a number input by the user.

x = float(input("Enter a number: "))
print("The square of the number = {}".format(x * x))
